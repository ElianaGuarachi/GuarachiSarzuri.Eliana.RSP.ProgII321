package sistemadispositivosdomoticos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;


public class Inventario<T extends CSVConvertible & Comparable<T> & java.io.Serializable> implements Almacenable<T>{

    private final List<T> elementos = new ArrayList<>();
    
    @Override
    public void agregar(T elemento) {
        Objects.requireNonNull(elemento, "Elemento nulo");
        elementos.add(elemento);
    }

    @Override
    public void eliminarSegun(Predicate<T> criterio) {
        Objects.requireNonNull(criterio, "Criterio nulo");
        Iterator<T> it = elementos.iterator();
        while (it.hasNext()) {
            T actual = it.next();
            if (criterio.test(actual)) {
                it.remove();
            }
        }
    }

    @Override
    public List<T> obtenerTodos() {
        return new ArrayList<>(elementos);
    }

    @Override
    public T buscar(Predicate<T> criterio) {
        Objects.requireNonNull(criterio, "Criterio nulo");
        for (T actual : elementos) {
            if (criterio.test(actual)) {
                return actual;
            }
        }
        return null;
    }

    @Override
    public void ordenar() {
       Collections.sort(elementos);
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        Objects.requireNonNull(comparador, "Comparador nulo");
        elementos.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> criterio) {
        Objects.requireNonNull(criterio, "Criterio nulo");
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;
    }

    @Override
    public List<T> transformar(Function<T, T> operador) {
        Objects.requireNonNull(operador, "Operador nulo");
        List<T> resultado = new ArrayList<>();
        for (T elemento : elementos) {
            resultado.add(operador.apply(elemento));
        }
        return resultado;
    }

    @Override
    public int contar(Predicate<T> criterio) {
        Objects.requireNonNull(criterio, "Criterio nulo");
        int contador = 0;
        for (T elemento : elementos) {
            if (criterio.test(elemento)) {
                contador++;
            }
        }
        return contador;
    }

    @Override
    public void guardarEnBinario(String ruta) throws Exception {
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        try (FileOutputStream archivo = new FileOutputStream(ruta);
                ObjectOutputStream serializar = new ObjectOutputStream(archivo)) {
            serializar.writeInt(elementos.size());
            for (T e : elementos) {
                serializar.writeObject(e);
            }
        }
    }

    @Override
    public void cargarDesdeBinario(String ruta) throws Exception {
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        try (ObjectInputStream lectura = new ObjectInputStream(new FileInputStream(ruta))) {
            int size = lectura.readInt();
            List<T> cargados = new ArrayList<>(size);
            cargados.add((T) lectura.readObject());
            elementos.clear();
            elementos.addAll(cargados);
        }
    }

    @Override
    public void guardarEnCSV(String ruta) throws Exception {
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(ruta))) {
            escritor.write(CSVConvertible.toHeaderCSV());
            for (T elem : elementos) {
                escritor.write(elem.toCSV());
                escritor.newLine();
            }
        }
    }

    @Override
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws Exception {
        Objects.requireNonNull(ruta, "La ruta no puede ser nula");
        Objects.requireNonNull(fromCSV, "La función no puede ser nula");
        try (BufferedReader lector = new BufferedReader(new FileReader(ruta))) {
            String linea;
            lector.readLine();
            List<T> cargados = new ArrayList<>();
            while ((linea = lector.readLine()) != null) {
                cargados.add(fromCSV.apply(linea));
            }
            elementos.clear();
            elementos.addAll(cargados);
        }
    }

    @Override
    public void guardarEnJSON(String ruta) throws Exception {

    }
    
}
