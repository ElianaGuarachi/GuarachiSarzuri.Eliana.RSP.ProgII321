package sistemadispositivosdomoticos;

import java.io.Serializable;
import java.util.Objects;

public class DispositivoDomotico implements Comparable<DispositivoDomotico>, CSVConvertible, Serializable{

    private final int codigo;
    private final String nombreModelo;
    private final Categoria categoria;
    private final int consumoWatts;
    private final int anioFabricacion;

    public DispositivoDomotico(int codigo, String nombreModelo, Categoria categoria, int consumoWatts, int anioFabricacion) {
        this.codigo = codigo;
        this.nombreModelo = nombreModelo;
        this.categoria = categoria;
        this.consumoWatts = consumoWatts;
        this.anioFabricacion = anioFabricacion;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreModelo() {
        return nombreModelo;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public int getConsumoWatts() {
        return consumoWatts;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(codigo);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DispositivoDomotico other = (DispositivoDomotico) obj;
        return this.codigo == other.codigo;
    }
    
    

    @Override
    public String toString() {
        return "Dispositivo{" + "codigo=" + codigo + ", nombreModelo=" + nombreModelo + ", categoria=" + categoria + ", consumoWatts=" + consumoWatts + ", anioFabricacion=" + anioFabricacion + '}';
    }

    @Override
    public int compareTo(DispositivoDomotico otroDispositivo) {
        if (this.anioFabricacion != otroDispositivo.anioFabricacion) {
            return Integer.compare(otroDispositivo.anioFabricacion, this.anioFabricacion);
        }
        return Integer.compare(this.consumoWatts, otroDispositivo.consumoWatts);

    }

    @Override
    public String toCSV() {
        StringBuilder sb = new StringBuilder();
        sb.append(codigo).append(',');
        sb.append(nombreModelo).append(',');
        sb.append(categoria).append(',');
        sb.append(consumoWatts).append(',');
        sb.append(anioFabricacion);
        return sb.toString();
    }
    
        static DispositivoDomotico fromCSV(String linea) {
        Objects.requireNonNull(linea, "La línea CSV no puede ser nula");
        
        String[] partes = linea.split(",");
        if (partes.length != 5) {
            throw new IllegalArgumentException("La línea CSV debe tener 5 campos: " + linea);
        }

        int id = Integer.parseInt(partes[0]);
        String nombreModelo = partes[1];
        Categoria categoria = Categoria.valueOf(partes[2]);
        int consumoWatts = Integer.parseInt(partes[3]);
        int anioFabricacion = Integer.parseInt(partes[4]);

        return new DispositivoDomotico(id, nombreModelo, categoria, consumoWatts, anioFabricacion);
    }
    
}
