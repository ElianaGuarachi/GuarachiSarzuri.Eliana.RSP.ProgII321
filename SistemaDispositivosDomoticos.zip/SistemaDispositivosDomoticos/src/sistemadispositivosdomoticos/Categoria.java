package sistemadispositivosdomoticos;

public enum Categoria {
    AMBIENTAL,
    ASISTENCIA,
    SEGURIDAD
}
