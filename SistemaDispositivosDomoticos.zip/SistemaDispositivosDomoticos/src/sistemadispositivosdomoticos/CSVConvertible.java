package sistemadispositivosdomoticos;

import java.util.Objects;

public interface CSVConvertible {
    
    String toCSV();

    static String toHeaderCSV() {
        
        return "codigo,nombreModelo,categoria,consumoWatts,anioFabricacion\n";
        
    }
    
    String toString();
}
